import Result from "./Result";

export { Result };
