import About from "./(about)";
import Services from "./(services)";
import NotFoundPage from "./page-not-found";
import QuizlyInfo from "./(quiz-info)";

export {
    About, NotFoundPage,
    Services,QuizlyInfo
};
