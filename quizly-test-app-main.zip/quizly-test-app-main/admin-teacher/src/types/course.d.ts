interface Course {
  _id: string;
  name: string;
  code: number;
}

type Courses = Course[];
