import MyStudentsComponent from "./MyStudents";
import AddQuizComponent from "./quiz/add";
import { ViewQuizComponent } from "./quiz/view";

export { AddQuizComponent, MyStudentsComponent, ViewQuizComponent };

