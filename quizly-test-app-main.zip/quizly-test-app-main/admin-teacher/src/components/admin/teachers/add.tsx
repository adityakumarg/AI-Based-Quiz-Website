import AddUser from "../../teacher-student/add"

const AddTeacherC = () => {
    return (
        <AddUser type="teacher" />
    )
}

export default AddTeacherC