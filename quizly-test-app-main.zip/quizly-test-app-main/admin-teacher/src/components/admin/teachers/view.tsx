import ViewUsers from "../../teacher-student/view"

const ViewTeachersC = () => {
    return (
        <ViewUsers type="teacher" />
    )
}

export default ViewTeachersC