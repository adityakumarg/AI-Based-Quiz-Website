import AddUser from "../../teacher-student/add"

const AddStudentC = () => {
    return (
        <AddUser type="student" />
    )
}

export default AddStudentC