import ViewUsers from "../../teacher-student/view"

const ViewStudentC = () => {
    return (
        <ViewUsers type="student" />
    )
}

export default ViewStudentC