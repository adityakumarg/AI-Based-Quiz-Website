const secretKey = import.meta.env.VITE_SECRET_KEY;

export const ENV = {
  secretKey,
};
