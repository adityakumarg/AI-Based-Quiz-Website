const _env = {
    SECRET_KEY: import.meta.env.VITE_SECRET_KEY,
    SERVER_KEY: import.meta.env.VITE_SERVER_KEY,
  };
  
  export default _env;
  