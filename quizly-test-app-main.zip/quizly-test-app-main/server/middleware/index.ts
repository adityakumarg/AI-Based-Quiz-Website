import { authStudent } from './authStudent';
import { authAdmin } from "./authAdmin";
import { authMiddleware } from "./authMiddleware";
import { authTeacher } from "./authTeacher";

export { authAdmin, authMiddleware, authTeacher ,authStudent};
