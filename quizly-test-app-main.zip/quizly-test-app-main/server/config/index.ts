import connectDb from "./connectDb";
import corsConfig from "./corsConfig";

export {
    connectDb,corsConfig
}